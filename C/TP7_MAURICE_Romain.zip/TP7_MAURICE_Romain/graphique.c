#include <stdio.h>
#include <MLV/MLV_all.h>
#define WIDTH 600
#define HEIGHT 600


void affiche_grille(){
    int x=10;
    int y=50;
    int nb_sqr = 9;
    int i;
    int j;
    for (i=0; i<nb_sqr; i++){
        for (j=0; j<nb_sqr; j++){
            MLV_draw_rectangle(x, y, WIDTH/nb_sqr, HEIGHT/nb_sqr, MLV_COLOR_WHITE );
            x=x+65;
        }
        y=y+65;
        x=10;
    }
    MLV_actualise_window();
}
/*
int keyboard_stop(){
    int key;
    key = MLV_ctrl_key_was_pressed("a");
    return key;
}
*/