#ifndef __IN_OUT__
#define __IN_OUT__

#include "affichage.h"

int fread_board(const char* file, Board board);

#endif
